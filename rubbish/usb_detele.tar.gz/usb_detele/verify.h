#ifndef _VERIFY_H
#define _VERIFY_H

#ifdef __cplusplus
extern "C" {
#endif

int verify_file(FILE * fp);

#ifdef __cplusplus
}
#endif

#endif
