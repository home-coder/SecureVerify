#ifndef MD5_CHECH_H
#define MD5_CHECH_H

extern int md5_check(char *filepath, char *checkpath);

#endif
